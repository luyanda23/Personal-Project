<?php
$db_name='mysql:host=127.0.0.1:3310;dbname=zahotel';
$db_user_name='root';
$db_user_pass='';

$connect= new PDO($db_name,$db_user_name,$db_user_pass);

function create_unique_id()
{
    $str='abcdefghijklmnopqrstuvwwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $rand=array();
    $lenght=strlen($str)-1;

    for($i = 0; $i < 20; $i++)
    {
        $n = mt_rand(0,$lenght);
        $rand[]=$str[$n];
    }
    return implode($rand);

}
?>
?>