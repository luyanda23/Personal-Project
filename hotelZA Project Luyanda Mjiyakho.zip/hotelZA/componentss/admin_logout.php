<?php

include 'connection.php';

setcookie('admin_id', '', time() - 1, '/');

header('location:../admins/login.php');

?>