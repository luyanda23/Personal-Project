<?php

include 'componentss/connection.php';

 if(isset($_COOKIE['user_id'])){
   $user_id =$_COOKIE['user_id'];
}else{
   setcookie('user_id',create_unique_id(),time()+ 60*60*24*30, '/');
   header('location:index.php');
} 




if (isset($_POST['check'])) {
   $check_in = $_POST['check_in'];
   $check_in = filter_var($check_in, FILTER_SANITIZE_STRING);

   $total = 0;
   $check_bookings = $connect->prepare("SELECT * FROM `bookings` WHERE check_in =?");

   try {
       $check_bookings->execute([$check_in]);
       while ($fetch_bookings = $check_bookings->fetch(PDO::FETCH_ASSOC)) {
           $total += $fetch_bookings['rooms'];
       }
   } catch (PDOException $e) {
       echo "Error: " . $e->getMessage();
   }

   echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>"; 

   echo "<script>
       document.addEventListener('DOMContentLoaded', function() {
           if ($total >= 20) {
               Swal.fire({
                   icon: 'warning',
                   title: 'No Rooms Available',
                   text: 'We have no rooms available.',
               });
           } else {
               Swal.fire({
                   icon: 'success',
                   title: 'Rooms Available',
                   text: 'Rooms are available.',
               });
           }
       });
   </script>";
}

//client booking
if (isset($_POST['book'])) {
   $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
   $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
   $rooms = filter_var($_POST['rooms'], FILTER_SANITIZE_STRING);
   $check_in = filter_var($_POST['check_in'], FILTER_SANITIZE_STRING);
   $check_out = filter_var($_POST['check_out'], FILTER_SANITIZE_STRING);
   $adults = filter_var($_POST['adults'], FILTER_SANITIZE_STRING);
   $children = isset($_POST['children']) ? filter_var($_POST['children'], FILTER_SANITIZE_STRING) : '';

   $total = 0;
   $check_bookings = $connect->prepare("SELECT * FROM `bookings` WHERE check_in =?");

   try {
       $check_bookings->execute([$check_in]);
       while ($fetch_bookings = $check_bookings->fetch(PDO::FETCH_ASSOC)) {
           $total += $fetch_bookings['rooms'];
       }
   } catch (PDOException $e) {
       echo "Error: " . $e->getMessage();
   }

   echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>";

   if ($total >= 20) {
       echo "<script>
              document.addEventListener('DOMContentLoaded', function() {
                  Swal.fire({
                      icon: 'warning',
                      title: 'No Rooms Available',
                      text: 'We have no rooms available.',
                  });
              });
          </script>";
   } else {
       $verify_bookings = $connect->prepare("SELECT * FROM `bookings` WHERE user_id = ? AND name = ? AND email = ? AND number = ? AND rooms = ? AND check_in = ? AND check_out = ? AND adults = ? AND children = ?");
       $verify_bookings->execute([$user_id, $name, $email, $number, $rooms, $check_in, $check_out, $adults, $children]);

       if ($verify_bookings->rowCount() > 0) {
           echo "<script>
                  document.addEventListener('DOMContentLoaded', function() {
                      Swal.fire({
                          icon: 'warning',
                          title: 'Booking Error',
                          text: 'You already have a booking with these details.',
                      });
                  });
              </script>";
       } else {
           $booking_id = create_unique_id(); 
           $book_room = $connect->prepare("INSERT INTO `bookings` (booking_id, user_id, name, email, number, rooms, check_in, check_out, adults, children) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
           $book_room->execute([$booking_id, $user_id, $name, $email, $number, $rooms, $check_in, $check_out, $adults, $children]);

           echo "<script>
                  document.addEventListener('DOMContentLoaded', function() {
                      Swal.fire({
                          icon: 'success',
                          title: 'Room successfully booked',
                          text: 'Room successfully booked.',
                      });
                  });
              </script>";
       }
   }
}
// end of client booking

//client sending message
if(isset($_POST['send'])){
  $id= create_unique_id();
   $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
   $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
   $message = filter_var($_POST['message'], FILTER_SANITIZE_STRING);

   $verify_messsage = $connect->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $verify_messsage->execute([$name,$email,$number,$message]);
   echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>";

   if($verify_messsage->rowCount()>0){

      echo "<script>
                  document.addEventListener('DOMContentLoaded', function() {
                      Swal.fire({
                          icon: 'warning',
                          title: 'Message Error',
                          text: 'Message already sent.',
                      });
                  });
              </script>";
   }else{
           $insert_message =$connect->prepare("INSERT INTO `messages` (id,name,email,number,message) VALUES (?, ?, ?, ?, ?)");
           $insert_message->execute([$id,$name,$email,$number,$message]);
      echo "<script>
                  document.addEventListener('DOMContentLoaded', function() {
                      Swal.fire({
                          icon: 'success',
                          title: 'message successfully sent',
                          text: 'message successfully sent.',
                      });
                  });
              </script>";
   }

}
?>
  
   



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Project </title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
</head>
<body>
     <!--<h1 ><?php echo 'LA Hotel' ?></h1> -->
    <!--<p class="name" id="name">Welcome to a hotel booking website that allows you to access various hotels all in one.-->
    </p>
</head>
<body>
<section class="header">
    <div class="flex">
        <a href="#home" class="Logo">LA Hotel</a>
        <a href="#availibility" class="btn">check availability</a>
        <div id="menu" class="btn fas fa-bars"></div>
    </div>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#reservation">reservation</a>
        <a href="#gallery">gallery</a>
        <a href="#contact">contact</a>
        <a href="#reviews">reviews</a>

    </nav>
</section>  

<section class="home" id="home">

   <div class="swiper home-slider">

      <div class="swiper-wrapper">

         <div class="box swiper-slide">
            <img src="images/home-img-1.jpg" alt="">
            <div class="flex">
               <h3>luxurious rooms</h3>
               <a href="#availability" class="btn">check availability</a>
            </div>
         </div>

         <div class="box swiper-slide">
            <img src="images/home-img-2.jpg" alt="">
            <div class="flex">
               <h3>foods and drinks</h3>
               <a href="#reservation" class="btn">make a reservation</a>
            </div>
         </div>

         <div class="box swiper-slide">
            <img src="images/home-img-3.jpg" alt="">
            <div class="flex">
               <h3>luxurious halls</h3>
               <a href="#contact" class="btn">contact us</a>
            </div>
         </div>

      </div>

      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>

   </div>

</section>

<!-- home section ends -->

<!-- availability section starts  -->

<section class="availability" id="availability">

   <form action="http://localhost/index.php" method="post">
      <div class="flex">
         <div class="box">
            <p>check in <span>*</span></p>
            <input type="date" name="check_in" class="input" required>
         </div>
         <div class="box">
            <p>check out <span>*</span></p>
            <input type="date" name="check_out" class="input" required>
         </div>
         <div class="box">
            <p>adults <span>*</span></p>
            <select name="adults" class="input" required>
               <option value="1">1 adult</option>
               <option value="2">2 adults</option>
               <option value="3">3 adults</option>
               <option value="4">4 adults</option>
               <option value="5">5 adults</option>
               <option value="6">6 adults</option>
            </select>
         </div>
         <div class="box">
            <p>childs <span>*</span></p>
            <select name="childs" class="input" required>
               <option value="-">0 child</option>
               <option value="1">1 child</option>
               <option value="2">2 childs</option>
               <option value="3">3 childs</option>
               <option value="4">4 childs</option>
               <option value="5">5 childs</option>
               <option value="6">6 childs</option>
            </select>
         </div>
         <div class="box">
            <p>rooms <span>*</span></p>
            <select name="rooms" class="input" required>
               <option value="1">1 room</option>
               <option value="2">2 rooms</option>
               <option value="3">3 rooms</option>
               <option value="4">4 rooms</option>
               <option value="5">5 rooms</option>
               <option value="6">6 rooms</option>
            </select>
         </div>
      </div>
      <input type="submit" value="check availability" name="check" class="btn">
   </form>

</section>

<!-- availability section ends -->

<!-- about section starts  -->

<section class="about" id="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img-1.jpeg" alt="">
      </div>
      <div class="content">
         <h3>best staff</h3>
         <p>La hotel has one of the best staffs to offer you the best exeperience money can buy.</p>
         <a href="#reservation" class="btn">make a reservation</a>
      </div>
   </div>

   <div class="row revers">
      <div class="image">
         <img src="images/about-img-2.jpg" alt="">
      </div>
      <div class="content">
         <h3>best foods</h3>
         <p>Our hotel offers a variety of delicious african food to fit your palate from traditionsl food to vegan food.The choice is yours.</p>
         <a href="#contact" class="btn">contact us</a>
      </div>
   </div>

   <div class="row">
      <div class="image">
         <img src="images/about-img-3.jpeg" alt="">
      </div>
      <div class="content">
         <h3>swimming pool</h3>
         <p>Enjoy our swimming pool while enjoying nature!</p>
         <a href="#availability" class="btn">check availability</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- services section starts  -->

<section class="services">

   <div class="box-container">

      <div class="box">
         <img src="images/icon-1.png" alt="">
         <h3>food & drinks</h3>
         <p>Enjoy a variety of african food.</p>
      </div>

      <div class="box">
         <img src="images/icon-2.png" alt="">
         <h3>outdoor dining</h3>
         <p>Enjoy the delicious food while enjoying nature.</p>
      </div>

      <div class="box">
         <img src="images/icon-3.png" alt="">
         <h3>Safari view</h3>
         <p>Enjoy the matural safari view in all angles</p>
      </div>

      <div class="box">
         <img src="images/icon-4.png" alt="">
         <h3>decorations</h3>
         <p>You will get to experiene everything African even in our decorations</p>
      </div>

      <div class="box">
         <img src="images/icon-5.png" alt="">
         <h3>swimming pool</h3>
         <p>Enjoy our swimming pool in the middle of nature.</p>
      </div>

   </div>

</section>

<!-- services section ends here --> 

<!-- reservation section starts  -->

<section class="reservation" id="reservation">

   <form action="" method="post">
      <h3>make a reservation</h3>
      <div class="flex">
         <div class="box">
            <p>your name <span>*</span></p>
            <input type="text" name="name" maxlength="50" required placeholder="enter your name" class="input">
         </div>
         <div class="box">
            <p>your email <span>*</span></p>
            <input type="email" name="email" maxlength="50" required placeholder="enter your email" class="input">
         </div>
         <div class="box">
            <p>your number <span>*</span></p>
            <input type="number" name="number" maxlength="10" min="0" max="9999999999" required placeholder="enter your number" class="input">
         </div>
         <div class="box">
            <p>rooms <span>*</span></p>
            <select name="rooms" class="input" required>
               <option value="1" selected>1 room</option>
               <option value="2">2 rooms</option>
               <option value="3">3 rooms</option>
               <option value="4">4 rooms</option>
               <option value="5">5 rooms</option>
               <option value="6">6 rooms</option>
            </select>
         </div>
         <div class="box">
            <p>check in <span>*</span></p>
            <input type="date" name="check_in" class="input" required>
         </div>
         <div class="box">
            <p>check out <span>*</span></p>
            <input type="date" name="check_out" class="input" required>
         </div>
         <div class="box">
            <p>adults <span>*</span></p>
            <select name="adults" class="input" required>
               <option value="1" selected>1 adult</option>
               <option value="2">2 adults</option>
               <option value="3">3 adults</option>
               <option value="4">4 adults</option>
               <option value="5">5 adults</option>
               <option value="6">6 adults</option>
            </select>
         </div>
         <div class="box">
            <p>childs <span>*</span></p>
            <select name="childs" class="input" required>
               <option value="0" selected>0 child</option>
               <option value="1">1 child</option>
               <option value="2">2 childs</option>
               <option value="3">3 childs</option>
               <option value="4">4 childs</option>
               <option value="5">5 childs</option>
               <option value="6">6 childs</option>
            </select>
         </div>
      </div>
      <input type="submit" value="book now" name="book" class="btn">
   </form>

</section>

<!-- reservation section ends -->

<!-- gallery section starts  -->

<section class="gallery" id="gallery">

   <div class="swiper gallery-slider">
      <div class="swiper-wrapper">
         <img src="images/gallery-img-1.jpg" class="swiper-slide" alt="">
         <img src="images/gallery-img-2.webp" class="swiper-slide" alt="">
         <img src="images/gallery-img-3.jpg" class="swiper-slide" alt="">
         <img src="images/gallery-img-4.jpg" class="swiper-slide" alt="">
         <img src="images/gallery-img-5.png" class="swiper-slide" alt="">
         <img src="images/gallery-img-6.jpg" class="swiper-slide" alt="">
      </div>
      <div class="swiper-pagination"></div>
   </div>

</section>

<!-- gallery section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

   <div class="row">

      <form action="" method="post">
         <h3>send us message</h3>
         <input type="text" name="name" required maxlength="50" placeholder="enter your name" class="box">
         <input type="email" name="email" required maxlength="50" placeholder="enter your email" class="box">
         <input type="number" name="number" required maxlength="10" min="0" max="9999999999" placeholder="enter your number" class="box">
         <textarea name="message" class="box" required maxlength="1000" placeholder="enter your message" cols="30" rows="10"></textarea>
         <input type="submit" value="send message" name="send" class="btn">
      </form>

      <div class="faq">
         <h3 class="title">frequently asked questions</h3>
         <div class="box active">
            <h3>how to cancel?</h3>
            <p>Please send us a message at most 3 days before booked date reqquesting to cancel.</p>
         </div>
         
         <div class="box">
            <h3>what are payment methods?</h3>
            <p>Payments are made online when booking online and we offer both card and cash payments when booking in person. </p>
         </div>
         
         <div class="box">
            <h3>what are the age requirements?</h3>
            <p>To book a room with us you must be 18 years and above.</p>
         </div>
      </div>

   </div>

</section>

<!-- contact section ends -->

<!-- reviews section starts  -->

<section class="reviews" id="reviews">

   <div class="swiper reviews-slider">

      <div class="swiper-wrapper">
         <div class="swiper-slide box">
            <img src="images/pic-1.png" alt="">
            <h3>john</h3>
            <p>Amazing hotel!</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/pic-2.png" alt="">
            <h3>Casandra</h3>
            <p>Really enjoyed the wildlife.</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/pic-3.png" alt="">
            <h3>Benard</h3>
            <p>The food was amazing.</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/pic-4.png" alt="">
            <h3>Amy</h3>
            <p>I will defiitely go back again</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/pic-5.png" alt="">
            <h3>Mark</h3>
            <p>The experience was beyond my wildest dreams</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/pic-6.png" alt="">
            <h3>Lisa</h3>
            <p>I loved everything about it.</p>
         </div>
      </div>

      <div class="swiper-pagination"></div>
   </div>


</section>

<!-- reviews section ends  -->

<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:1234567890"><i class="fas fa-phone"></i> +123-456-7890</a>
      </div>

      <div class="box">
         <a href="#home">home</a>
         <a href="#about">about</a>
         <a href="#reservation">reservation</a>
         <a href="#gallery">gallery</a>
         <a href="#contact">contact</a>
         <a href="#reviews">reviews</a>
      </div>

      

   </div>

   <div class="credit">all rights reseved!</div>

</section>





<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script src="js/script.js"></script>
<?php include 'componentss/messages.php'; ?>
<?php include 'footer/footer.php';?>
<script>
   document.addEventListener('DOMContentLoaded', function () {
      var swiper = new Swiper('.home-slider', {
         slidesPerView: 1,
         spaceBetween: 30,
         navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
         },
      });
   });
</script>

<script>
   document.addEventListener('DOMContentLoaded', function () {
      var swiper = new Swiper('.gallery-slider', {
         slidesPerView: 1,
         spaceBetween: 30,
         pagination: {
            el: '.swiper-pagination',
            clickable: true,
         },
      });
   });
</script>

<script>
   document.addEventListener('DOMContentLoaded', function () {
      var swiper = new Swiper('.reviews-slider', {
         slidesPerView: 1,
         spaceBetween: 30,
         pagination: {
            el: '.swiper-pagination',
            clickable: true,
         },
      });
   });
</script>

</body>
</html>


</html>