
<script src="assets/js/sweetalerts.js"></script>
<?php
 if(isset($_COOKIE['user_id'])){
    $user_id =$_COOKIE['user_id'];
 }else{
    setcookie('user_id',create_unique_id(),time()+ 60*60*24*30, '/');
    header('location:index.php');
 } 
 
 
 if (isset($_POST['check'])) {
    $check_in = $_POST['check_in'];
    $check_in = filter_var($check_in, FILTER_SANITIZE_STRING);
 
    $total = 0;
    $check_bookings = $connect->prepare("SELECT * FROM `bookings` WHERE check_in =?");
 
    try {
        $check_bookings->execute([$check_in]);
        while ($fetch_bookings = $check_bookings->fetch(PDO::FETCH_ASSOC)) {
            $total += $fetch_bookings['rooms'];
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
 
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>"; // Include SweetAlert2 script
 
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            if ($total >= 20) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No Rooms Available',
                    text: 'We have no rooms available.',
                });
            } else {
                Swal.fire({
                    icon: 'success',
                    title: 'Rooms Available',
                    text: 'Rooms are available.',
                });
            }
        });
    </script>";
 }
   

?>