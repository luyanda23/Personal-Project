<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Dashboard </title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


   <link rel="stylesheet" href="../css/admin_style.css">
   <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
</head>
<body>
<?php  include '../componentss/admin_header.php' ?>










<script src="../js/admin_script.js"></script>
</body>
</html>
