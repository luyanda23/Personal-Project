﻿namespace SOP_Client
{
    partial class Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpdateDataGrid = new System.Windows.Forms.DataGridView();
            this.buttonUpdateData = new System.Windows.Forms.Button();
            this.buttonBackHome = new System.Windows.Forms.Button();
            this.nameUpdate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lab = new System.Windows.Forms.Label();
            this.textUpdate = new System.Windows.Forms.TextBox();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // UpdateDataGrid
            // 
            this.UpdateDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UpdateDataGrid.Location = new System.Drawing.Point(33, 142);
            this.UpdateDataGrid.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateDataGrid.Name = "UpdateDataGrid";
            this.UpdateDataGrid.RowHeadersWidth = 51;
            this.UpdateDataGrid.Size = new System.Drawing.Size(841, 308);
            this.UpdateDataGrid.TabIndex = 3;
            this.UpdateDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UpdateDataGrid_CellContentClick);
            // 
            // buttonUpdateData
            // 
            this.buttonUpdateData.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonUpdateData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonUpdateData.Location = new System.Drawing.Point(86, 493);
            this.buttonUpdateData.Name = "buttonUpdateData";
            this.buttonUpdateData.Size = new System.Drawing.Size(108, 44);
            this.buttonUpdateData.TabIndex = 4;
            this.buttonUpdateData.Text = "Update";
            this.buttonUpdateData.UseVisualStyleBackColor = true;
            this.buttonUpdateData.Click += new System.EventHandler(this.buttonUpdateData_Click);
            // 
            // buttonBackHome
            // 
            this.buttonBackHome.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonBackHome.ForeColor = System.Drawing.Color.Purple;
            this.buttonBackHome.Location = new System.Drawing.Point(698, 493);
            this.buttonBackHome.Name = "buttonBackHome";
            this.buttonBackHome.Size = new System.Drawing.Size(134, 44);
            this.buttonBackHome.TabIndex = 6;
            this.buttonBackHome.Text = "Back Home";
            this.buttonBackHome.UseVisualStyleBackColor = true;
            this.buttonBackHome.Click += new System.EventHandler(this.buttonBackHome_Click);
            // 
            // nameUpdate
            // 
            this.nameUpdate.AutoSize = true;
            this.nameUpdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nameUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.nameUpdate.Location = new System.Drawing.Point(83, 27);
            this.nameUpdate.Name = "nameUpdate";
            this.nameUpdate.Size = new System.Drawing.Size(84, 24);
            this.nameUpdate.TabIndex = 7;
            this.nameUpdate.Text = "Enter ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(83, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Enter Password:";
            // 
            // lab
            // 
            this.lab.AutoSize = true;
            this.lab.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lab.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lab.Location = new System.Drawing.Point(455, 27);
            this.lab.Name = "lab";
            this.lab.Size = new System.Drawing.Size(169, 24);
            this.lab.TabIndex = 9;
            this.lab.Text = "Enter Client Name:";
            // 
            // textUpdate
            // 
            this.textUpdate.Location = new System.Drawing.Point(189, 27);
            this.textUpdate.Name = "textUpdate";
            this.textUpdate.Size = new System.Drawing.Size(100, 22);
            this.textUpdate.TabIndex = 10;
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(257, 98);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(163, 22);
            this.textPassword.TabIndex = 11;
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(651, 27);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(204, 22);
            this.textName.TabIndex = 12;
            // 
            // Update
            // 
            this.ClientSize = new System.Drawing.Size(922, 549);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.textPassword);
            this.Controls.Add(this.textUpdate);
            this.Controls.Add(this.lab);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.nameUpdate);
            this.Controls.Add(this.buttonBackHome);
            this.Controls.Add(this.buttonUpdateData);
            this.Controls.Add(this.UpdateDataGrid);
            this.Name = "Update";
            ((System.ComponentModel.ISupportInitialize)(this.UpdateDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView UpdateData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox updateID;
        private System.Windows.Forms.TextBox updateName;
        private System.Windows.Forms.TextBox updatePassword;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView UpdateDataGrid;
        private System.Windows.Forms.Button buttonUpdateData;
        private System.Windows.Forms.Button buttonBackHome;
        private System.Windows.Forms.Label nameUpdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lab;
        private System.Windows.Forms.TextBox textUpdate;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.TextBox textName;
    }
}