﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOP_Client
{
    public static class CurrentUser
    {
        public static string name{ get; set; }
        public static string password{ get; set; }
    }
}
