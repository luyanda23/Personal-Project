﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management.Instrumentation;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using RestSharp;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SOP_Client
{
    public partial class Main : Form
    {

        public Main()
        {
            InitializeComponent();
            InitializeUsersDataGridView();
            RefreshUserData();
           
        }

        RestClient restClient = new RestClient("http://rest/php/client.php");

        string url = "http://rest/php/";
        string route = "client.php";



        void InitializeUsersDataGridView()
        {
            usersData.Columns.Add("id", "ID");
            usersData.Columns.Add("name", "name");
            usersData.Columns.Add("password", "Password");
        }
        public void RefreshUserData()
        {
            try
            {
                var client = new RestClient(url);

                var request = new RestRequest(route, Method.GET);

                IRestResponse<List<User>> response = client.Execute<List<User>>(request);
                usersData.Rows.Clear();

                foreach (User user in response.Data)
                {

                    usersData.Rows.Add(user.ID, user.name, user.password);

                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void getButton_Click(object sender, EventArgs e)
        {
            RefreshUserData();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            Insert insert = new Insert();
            insert.Show();
            this.Hide();
           
            
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            Update update= new Update();
            update.Show();
            this.Hide();

           
        }
    



        private void deleteButton_Click(object sender, EventArgs e)
        {
            Delete pro = new Delete();
            pro.Show();
            this.Hide();


        }

        private void buttongGET_Click(object sender, EventArgs e)
        {
            getClientById getClientById = new getClientById();
            getClientById.Show();
            this.Hide();
        }
    }
}
