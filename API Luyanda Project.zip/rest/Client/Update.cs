﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Converters;
using System.Web.Routing;
using System.Xml.Linq;

namespace SOP_Client
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();

            InitializeDataGridView();
            RefreshUserData();
        }

        private void InitializeDataGridView()
        {
            

            UpdateDataGrid.CellContentClick += UpdateDataGrid_CellContentClick;
        }

        private const string Url = "http://rest/php/client.php";
        string url = "http://rest/php/";
        string route = "client.php";

        private List<User> users;
        private User selectedUser;
        private void RefreshUserData()
        {
            try
            {
                var client = new RestClient(Url);
                var request = new RestRequest( Method.GET);

                IRestResponse<List<User>> response = client.Execute<List<User>>(request);

               
                

                users = response.Data;

                UpdateDataGrid.DataSource = users;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void UpdateDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < UpdateDataGrid.Rows.Count)
            {
                int selectedUserId = Convert.ToInt32(UpdateDataGrid.Rows[e.RowIndex].Cells[0].Value);
                string selectedUserName = Convert.ToString(UpdateDataGrid.Rows[e.RowIndex].Cells[1].Value);
                string selectedUserPassword = Convert.ToString(UpdateDataGrid.Rows[e.RowIndex].Cells[2].Value);

                selectedUser = new User { ID = selectedUserId, name = selectedUserName, password = selectedUserPassword };

                textUpdate.Text = selectedUserId.ToString();
                textName.Text = selectedUserName;
                textPassword.Text = selectedUserPassword;
            }
        }

        private async void buttonUpdateData_Click(object sender, EventArgs e)
        {
            int userId;
            if (int.TryParse(textUpdate.Text, out userId))
            {
                string name = textName.Text;
                string password = textPassword.Text;

                await UpdateUserAsync(userId, name, password);
            }
            else
            {
                MessageBox.Show("Please enter a valid user ID.");
            }
        }

        private async Task UpdateUserAsync(int userId, string name, string password)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                
                    string jsonData = $"{{\"id\": {userId}, \"name\": \"{name}\", \"password\": \"{password}\"}}";
                    var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                   
                    HttpResponseMessage response = await client.PostAsync(Url, content);

               
                    if (response.IsSuccessStatusCode)
                    {
        
                        string responseContent = await response.Content.ReadAsStringAsync();

                        MessageBox.Show("User updated successfully.");

                  
              
                    }
                    else
                    {
                        MessageBox.Show($"Error updating user. StatusCode: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }
        }

        private void buttonRefreshUpdate_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonBackHome_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Hide();
        }
    }
}

