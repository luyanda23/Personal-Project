﻿namespace SOP_Client
{
    partial class getClientById
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.IDTextbox = new System.Windows.Forms.TextBox();
            this.getDataID = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.DataGetID = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DataGetID)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Coral;
            this.label1.Location = new System.Drawing.Point(65, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Select data ID:";
            // 
            // IDTextbox
            // 
            this.IDTextbox.Location = new System.Drawing.Point(244, 12);
            this.IDTextbox.Multiline = true;
            this.IDTextbox.Name = "IDTextbox";
            this.IDTextbox.Size = new System.Drawing.Size(124, 36);
            this.IDTextbox.TabIndex = 7;
            // 
            // getDataID
            // 
            this.getDataID.Location = new System.Drawing.Point(69, 401);
            this.getDataID.Name = "getDataID";
            this.getDataID.Size = new System.Drawing.Size(126, 49);
            this.getDataID.TabIndex = 9;
            this.getDataID.Text = "GetData+ID";
            this.getDataID.UseVisualStyleBackColor = true;
            this.getDataID.Click += new System.EventHandler(this.getDataID_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.Location = new System.Drawing.Point(413, 401);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(133, 48);
            this.buttonMain.TabIndex = 10;
            this.buttonMain.Text = "Back To Main";
            this.buttonMain.UseVisualStyleBackColor = true;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // DataGetID
            // 
            this.DataGetID.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGetID.Location = new System.Drawing.Point(23, 99);
            this.DataGetID.Margin = new System.Windows.Forms.Padding(4);
            this.DataGetID.Name = "DataGetID";
            this.DataGetID.RowHeadersWidth = 51;
            this.DataGetID.Size = new System.Drawing.Size(636, 241);
            this.DataGetID.TabIndex = 20;
            // 
            // getClientById
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 512);
            this.Controls.Add(this.DataGetID);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.getDataID);
            this.Controls.Add(this.IDTextbox);
            this.Controls.Add(this.label1);
            this.Name = "getClientById";
            this.Text = "getClientById";
            ((System.ComponentModel.ISupportInitialize)(this.DataGetID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox IDTextbox;
        private System.Windows.Forms.Button getDataID;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.DataGridView DataGetID;
    }
}