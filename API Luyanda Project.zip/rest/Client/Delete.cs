﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOP_Client
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
            InitializeUsersDataGridView();
        }
        private const string PhpDeleteUrl = "http://rest/php/client.php";

        RestClient restClient = new RestClient("http://rest/php/client.php");

        string url = "http://rest/php/";
        string route = "client.php";



         private void InitializeUsersDataGridView()
        {
            DeleteData.Columns.Add("id", "ID");
            DeleteData.Columns.Add("name", "name");
            DeleteData.Columns.Add("password", "Password");
        }
        private void RefreshUserData()
        {
            try
            {
                var client = new RestClient(url);

                var request = new RestRequest(route, Method.GET);

                IRestResponse<List<User>> response = client.Execute<List<User>>(request);

                DeleteData.Rows.Clear();
                foreach (User user in response.Data)
                {

                    DeleteData.Rows.Add(user.ID, user.name, user.password);

                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }


        private async void button1_Click(object sender, EventArgs e)
        {
            int userIdToDelete;
            if (int.TryParse(IDTextbox.Text, out userIdToDelete))
            {
               
                await DeleteUserData(userIdToDelete);
            }
            else
            {
                MessageBox.Show("Please enter a valid user ID.");
            }

          
        }
        private async Task DeleteUserData(int userId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                   
                    HttpResponseMessage response = await client.DeleteAsync($"{PhpDeleteUrl}?id={userId}");

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("User data deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show($"Failed to delete user data. Status code: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void GetData_Click(object sender, EventArgs e)
        {
            RefreshUserData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Hide();
        }
    }
}
