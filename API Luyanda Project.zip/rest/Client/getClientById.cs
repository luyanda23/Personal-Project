﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace SOP_Client
{
    public partial class getClientById : Form
    {
        public getClientById()
        {
            InitializeComponent();
        }
        string url = "http://rest/php/";
        string route = "client.php";
        private void buttonMain_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Hide();
        }


        
       

        private void getDataID_Click(object sender, EventArgs e)
        {
            var client = new RestClient(url);

            String ROUTE = "client.php"+"?id=" + IDTextbox.Text;

            var request = new RestRequest(ROUTE, Method.GET);

            IRestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                try
                {
                    // Parsing  the response content into a list of ClientData objects
                    var content = response.Content;
                    var clientDataList = Newtonsoft.Json.JsonConvert.DeserializeObject<System.Collections.Generic.List<ClientData>>(content);

                    // Bind the data to the DataGridView
                    DataGetID.DataSource = clientDataList;
                }
                catch (Newtonsoft.Json.JsonSerializationException ex)
                {
                    MessageBox.Show($"Error deserializing JSON: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show($"Error fetching client data. StatusCode: {response.StatusCode}");
            }
        }
        public class ClientData
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Password { get; set; }
            
        }
    }

}

