﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOP_Client
{
    public partial class Insert : Form
    {
        public Insert()
        {
            InitializeComponent();
            RefreshUserData();
        }
        string url = "http://rest/php/";
        string route = "client.php";
        void InitializeUsersDataGridView()
        {
            InsertData.Columns.Add("id", "ID");
            InsertData.Columns.Add("name", "name");
            InsertData.Columns.Add("password", "Password");
        }
        public void RefreshUserData()
        {
            try
            {
                var client = new RestClient(url);

                var request = new RestRequest(route, Method.GET);

                IRestResponse<List<User>> response = client.Execute<List<User>>(request);
                InsertData.Rows.Clear();

                foreach (User user in response.Data)
                {

                    InsertData.Rows.Add(user.ID, user.name, user.password);
                    MessageBox.Show("DATA INSERTED");

                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var client = new RestClient(url);

            var request = new RestRequest(route, Method.POST);

            request.RequestFormat = DataFormat.Json;

            request.AddBody(new User
            {
                name = ClientName.Text,

                password = ClientPassword.Text

            });

            IRestResponse response = client.Execute(request);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

    }
}
