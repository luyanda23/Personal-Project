﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using RestSharp;
using System;
using System.Windows.Forms;
using System.Reflection.Emit;

namespace SOP_Client
{

    public partial class UserHandler
    {
        private RestClient restClient;
        private Main mainForm;
        private RequestType requestType;

        public UserHandler(RestClient restClient, Main mainForm, RequestType requestType)
        {
            this.restClient = restClient;
            this.mainForm = mainForm;
            this.requestType = requestType;
            //SetFormElements();
        }
    }

           
    }
    