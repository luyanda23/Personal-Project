﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOP_Client
{
    public enum RequestType
    {
        POST,
        PUT,
        DELETE,
        LOGIN
    }
}
