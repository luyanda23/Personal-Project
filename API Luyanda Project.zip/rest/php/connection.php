<?php
    function getCon(){
    $db_name='mysql:host=127.0.0.1:3310;dbname=loggin';
   $db_user_name='root';
   $db_user_pass='';
   
   return $connect= new PDO($db_name,$db_user_name,$db_user_pass);
}
    
?>