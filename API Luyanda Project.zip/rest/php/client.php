<?php

include("connection.php");
include ("conf.php");

$request = $_SERVER['REQUEST_METHOD'];
$connect=getCon();

switch($request) {

    case 'GET':
     // GET with id
      if(!empty($_GET["id"]))  
      {
         $id=intval($_GET["id"]);  getUSersid($id);
      }
      else
      {
         getUsers(); //all employees
      }
     break;
  
   case 'POST':
  
      
  
       addUser();  break;
  
    case 'PUT':
  

  
      $id=intval($_GET["id"]);
  
     updateUser($id);
  
     break;
  
   case 'DELETE':
  
     
  
      $id=intval($_GET["id"]);
  
      deleteUser($id);
  
      break;
  
   default:
  

      header("HTTP/1.1 405 Method Not Allowed");
  
      break;
  
  }

function getUsers(){
    global $connect;

    $result= $connect -> prepare("SELECT * FROM clients;");
    $result->execute();

    $output= $result -> fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json'); //send the header

    echo json_encode($output); //data in JSON format
}

function getUsersid($id)
{
    global $connect;

    $query = "SELECT * FROM clients";

    if ($id != 0) {
        $query .= " WHERE id = :id LIMIT 1";
    }

    $response = array();

    try {
        $stmt = $connect->prepare($query);

        if ($id != 0) {
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        }

        $stmt->execute();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $response[] = $row;
        }

        header('Content-Type: application/json');
        echo json_encode($response);
    } catch (PDOException $e) {
        // Handle the exception 
        header('Content-Type: application/json');
        echo json_encode(['error' => $e->getMessage()]);
    }
}



function addUser(){
    global $connect;
    $data = json_decode(file_get_contents('php://input'), true);        
    $name=$data['name']; 
    $password=$data['password'];
    $result = $connect -> prepare("INSERT INTO clients(name, password) VALUES (:name, :password);");

    $result->bindValue(':name',$name);
    $result->bindValue(':password',$password);

    $result->execute();

    header('Content-Type: application/json'); //send the header

    echo json_encode($result); //data in JSON format
}

function updateUser($id) {
    global $connect;

    $data = json_decode(file_get_contents('php://input'), true);

    
        $id = $data['id'];
        $name = $data["name"];
        $password = $data["password"];

        $sql = $connect->prepare("UPDATE clients SET name = :name, password = :password WHERE id = :id");

        $sql->bindParam(':id', $id, PDO::PARAM_INT);
        $sql->bindParam(':name', $name, PDO::PARAM_STR);
        $sql->bindParam(':password', $password, PDO::PARAM_STR);

    
        $sql->execute();
      

        header('Content-Type: application/json');
        echo json_encode($sql);
    
}

function deleteUser($id){
    global $connect;

    try {
        $query = "DELETE FROM clients WHERE id = :id";
        $stmt = $connect->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
        if ($stmt->execute()) {
            $response = array(
                'status' => 1,
                'status_message' => 'Employee Deleted Successfully.'
            );
        } else {
            $response = array(
                'status' => 0,
                'status_message' => 'Employee Deletion Failed.'
            );
        }
    } catch (PDOException $e) {
        $response = array(
            'status' => 0,
            'status_message' => 'Employee Deletion Failed. Error: ' . $e->getMessage()
        );
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
}

function userExists($name){
    global $connect;

    $result = count($connect -> query("SELECT * FROM clients WHERE name = '$name';")->fetchAll(MYSQLI_ASSOC));

    return $result > 0;
}

?>