<?
require_once 'conf.php';
require_once 'client.php';




$page = array_key_exists('page', $_GET) ? $_GET['page'] : 'home';
