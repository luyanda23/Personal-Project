<?php

define('BASE_URL', 'http://rest/');

define('BASE_PATH', __DIR__);
